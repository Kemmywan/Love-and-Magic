# crypt-it

In this challenge, we use RSA to encrypt the message which is padded with OAEP mode, and we save the private key and the public key in pem format.

Your mission is to decrypt the message using this private key.